import java.util.ArrayList;
import java.util.Arrays;

public class School {
    private ArrayList<Teacher> teachers = new ArrayList<>();
    private ArrayList<Student> students = new ArrayList<>();
    private String classNumber;
    private String classSize;
    private String schoolName;

   // Constructor
    School(String schoolName, String classNumber, String classSize, ArrayList teachers, ArrayList students){
        this.schoolName = schoolName;
        this.classNumber = classNumber;
        this.classSize = classSize;
        this.teachers = teachers;
        this.students = students;


    }

    // This method takes an ArrayList of teachers and a teacher and adds the teacher to the ArrayList
    public void addTeacher(ArrayList s, Teacher t){
        s.add(t);

    }
    // This method takes an ArrayList of teachers and a teacher. It finds the index of that teacher and removes it from the ArrayList
    public void removeTeacher(ArrayList s, Teacher t){
        int w = s.indexOf(t);
        s.remove(w);

    }
    // This method prints off the first name, last name and subject of all teachers in the ArrayList submitted
    public void  showTeachers(ArrayList <Teacher> s){
        for(int i = 0; i< s.size(); i++){
            Teacher t = s.get(i);
            t.whichTeacher();
        }

    }
    //This method takes an ArrayList of students and a student and adds the student to the ArrayList
    public void addStudent(ArrayList s, Student t){
        s.add(t);
    }
    // This method takes an ArrayList of students and a students. It finds the index of that student and removes it from the ArrayList
    public void removeStudent(ArrayList s, Student t){
        int w = s.indexOf(t);
        s.remove(w);
    }
    // This methods takes and ArrayList and prints the first name, last name and grade of all the students in the ArrayList.
    public void showStudents (ArrayList <Student> s){
        for( int i = 0; i < s.size(); i ++){
            Student t = s.get(i);
            t.whichStudent();
        }
    }
    //getters and setters

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public String getClassSize() {
        return classSize;
    }

    public void setClassSize(String classSize) {
        this.classSize = classSize;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
}

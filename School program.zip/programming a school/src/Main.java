import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Teacher> baltimoreteachers = new ArrayList<>();
        ArrayList<Student> baltimorestudents = new ArrayList<>();

        Student emily = new Student("Emily", "Bird","11");
        Student francis = new Student("Francis", "Hunt", "10");
        Student damian = new Student("Damian", "Andrews", "12");
        Student aurora = new Student ("Aurora", "Xavier", "8");
        Student travis = new Student("Travis", "Tam", "9");
        Student hank = new Student("Hank", "Reeves","11");
        Student robert = new Student("Robert", "Alvales", "9");
        Student riley = new Student ("Riley", "Thompson", "10");
        Student jenny = new Student ("Jenny", "Yang", "12");
        Student kathy = new Student("Kathy", "Michealson", "8");

        Teacher addison = new Teacher("Addison","Blunt", "Biology");
        Teacher gabriel = new Teacher ("Gabriel","Ross", "Arts");
        Teacher hailey = new Teacher ("Hailey", "Gibson", "Math");

        School baltimorehigh = new School("Baltimore high", "93", "17", baltimoreteachers, baltimorestudents);

        baltimorehigh.addStudent(baltimorestudents,emily);
        baltimorehigh.addStudent(baltimorestudents,francis);
        baltimorehigh.addStudent(baltimorestudents,damian);
        baltimorehigh.addStudent(baltimorestudents,aurora);
        baltimorehigh.addStudent(baltimorestudents,travis);
        baltimorehigh.addStudent(baltimorestudents,hank);
        baltimorehigh.addStudent(baltimorestudents,robert);
        baltimorehigh.addStudent(baltimorestudents,riley);
        baltimorehigh.addStudent(baltimorestudents,jenny);
        baltimorehigh.addStudent(baltimorestudents,kathy);
        baltimorehigh.addTeacher(baltimoreteachers, gabriel);
        baltimorehigh.addTeacher(baltimoreteachers, addison);
        baltimorehigh.addTeacher(baltimoreteachers, hailey);
        baltimorehigh.showStudents(baltimorestudents);
        baltimorehigh.showTeachers(baltimoreteachers);

        baltimorehigh.removeStudent(baltimorestudents,emily);
        baltimorehigh.removeStudent(baltimorestudents,francis);
        baltimorehigh.removeTeacher(baltimoreteachers, gabriel);
        baltimorehigh.showStudents(baltimorestudents);
        baltimorehigh.showTeachers(baltimoreteachers);
















    }
}

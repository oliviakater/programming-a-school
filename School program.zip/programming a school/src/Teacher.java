public class Teacher {
    /*
    This class can be used to create teachers. It includes a constructor that will take in a first name, last name and subject taught
    by the teacher and it will store this as a teacher.
     */
    private String firstName;
    private String lastName;
    private String subject;
    //constructor
    Teacher(String firstName, String lastName, String subject){
        this.firstName = firstName;
        this.lastName = lastName;
        this.subject = subject;

    }
    //getters and setters


    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
    // This method takes a teacher and print out their first and last names along with the subject that they teach.
    public void whichTeacher(){
        System.out.println("Name: " + firstName + " " + lastName + "  Subject: " + subject);

    }
}

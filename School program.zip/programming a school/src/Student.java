public class Student {
    /* This class can be used to create students. It includes a constructor that will take in a first name, last name and grade
    and it will store this as a student. It will also assign the student an identifying number which will be different for every student.
     */
    private String firstName;
    private String lastName;
    private String grade;
    static int id = 1;
    private int studentNumber;
    //This is the constructor
    Student(String firstName, String lastName, String grade){
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
        studentNumber = id;
        id ++;

    }
    //getters and setters

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public int getStudentNumber() {
        return studentNumber;
    }

    public void setStudentNumber(int studentNumber) {
        this.studentNumber = studentNumber;
    }
    // This method will take a student and prints out their first and last names along with their grade.
    public void whichStudent(){
        System.out.println("Name: " + firstName +" " + lastName + "  Grade: " + grade);
    }
}
